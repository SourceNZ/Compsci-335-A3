﻿namespace WebApplication1

open System
open System.Collections.Generic
open System.Data.Services
open System.Data.Services.Common
open System.Linq
open System.ServiceModel
open System.ServiceModel.Web
open System.Web
open System.Xml.Linq

// UDO
